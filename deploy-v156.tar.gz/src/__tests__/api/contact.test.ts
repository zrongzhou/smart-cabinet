import { describe, it, expect, vi, beforeEach } from 'vitest';
import { POST } from '@/app/api/contact/route';

// Mock the Prisma client module
vi.mock('@prisma/client', () => {
  // Create mock instance inside factory to avoid hoisting issues
  const mockInstance = {
    contactMessage: {
      create: vi.fn().mockResolvedValue({
        id: 'test-id-123',
        name: 'Test User',
        email: 'test@example.com',
        subject: 'general',
        message: 'Test message',
        locale: 'en',
      }),
    },
    $disconnect: vi.fn().mockResolvedValue(undefined),
  };

  return {
    PrismaClient: vi.fn().mockImplementation(() => mockInstance),
  };
});

// Mock NextResponse
vi.mock('next/server', async () => {
  const actual = await vi.importActual('next/server');
  return {
    ...actual,
    NextResponse: {
      json: vi.fn((body: any, init?: any) => ({
        status: init?.status || 200,
        json: async () => body,
      })),
    },
  };
});

describe('/api/contact POST endpoint', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.resetModules();
  });

  // Debug test to verify Prisma mock
  it('DEBUG: should mock @prisma/client correctly', async () => {
    const { PrismaClient } = await import('@prisma/client');
    const client = new PrismaClient();
    console.log('Mocked PrismaClient instance:', client);
    console.log('contactMessage:', client.contactMessage);
    expect(client.contactMessage).toBeDefined();
    expect(client.$disconnect).toBeDefined();
  });

  it('should return 400 if required fields are missing (name)', async () => {
    const request = new Request('http://localhost:3000/api/contact', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: 'test@example.com',
        subject: 'general',
        message: 'Test message',
      }),
    });

    const response = await POST(request as any);
    const data = await response.json();

    expect(response.status).toBe(400);
    expect(data.error).toContain('Missing required fields');
  });

  it('should return 400 if email is invalid', async () => {
    const request = new Request('http://localhost:3000/api/contact', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Test User',
        email: 'invalid-email',
        subject: 'general',
        message: 'Test message',
      }),
    });

    const response = await POST(request as any);
    const data = await response.json();

    expect(response.status).toBe(400);
    expect(data.error).toContain('Invalid email format');
  });

  it('should return 400 if subject is invalid', async () => {
    const request = new Request('http://localhost:3000/api/contact', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Test User',
        email: 'test@example.com',
        subject: 'invalid-subject',
        message: 'Test message',
      }),
    });

    const response = await POST(request as any);
    const data = await response.json();

    expect(response.status).toBe(400);
    expect(data.error).toContain('Invalid subject');
  });

  it('should return 200 if all fields are valid', async () => {
    const request = new Request('http://localhost:3000/api/contact', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Test User',
        email: 'test@example.com',
        phone: '+86 123 4567 8900',
        subject: 'general',
        message: 'This is a test message for the contact form.',
      }),
    });

    const response = await POST(request as any);
    const data = await response.json();

    // Debug output
    if (response.status !== 200) {
      console.log('DEBUG - Response status:', response.status);
      console.log('DEBUG - Response data:', data);
    }

    expect(response.status).toBe(200);
    expect(data.success).toBe(true);
    expect(data.id).toBeDefined();
  });
});
