import type { Metadata, Viewport } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';

const inter = Inter({ subsets: ['latin'] });

// Use generateMetadata (async) instead of static metadata
// This allows child pages to override the title via their own generateMetadata
export async function generateMetadata(): Promise<Metadata> {
  return {
    title: 'Smart Cabinet - Intelligent Storage Solutions',
    description: 'Leading provider of intelligent storage solutions for modern businesses worldwide.',
    keywords: ['smart cabinet', 'vending machine', 'intelligent locker', 'storage solutions'],
  };
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className} suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
